import java.util.Scanner;

public class Booking {
    private Movie[] movies;
    private Scanner scanner;

    public Booking() {
        movies = new Movie[] {
            new Movie("Dilwale Dulhania Le Jaenge :", new Showtime[] {
                new Showtime("10:00 AM", 50),
                new Showtime("3:00 PM", 50),
                new Showtime("7:00 PM", 50)
            }),
            new Movie("3 Idiots : ", new Showtime[] {
                new Showtime("11:00 AM", 40),
                new Showtime("4:00 PM", 40),
                new Showtime("8:00 PM", 40)
            }),
            new Movie("Rang De Basanti : ", new Showtime[] {
                new Showtime("12:00 PM", 30),
                new Showtime("5:00 PM", 30),
                new Showtime("9:00 PM", 30)
            }),

              new Movie("Bhagat Singh : ", new Showtime[] {
                new Showtime("2:00 PM", 30),
                new Showtime("7:00 PM", 30),
                new Showtime("10:00 PM", 30)
            })

        };
        scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("Welcome to Movie Ticket Booking System!");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. View Movies and Showtimes");
            System.out.println("2. Book Tickets");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    viewMovies();
                    break;
                case "2":
                    bookTickets();
                    break;
                case "3":
                    System.out.println("Thank you for using the Movie Ticket Booking System. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice, please enter 1, 2, or 3.");
            }
        }
    }

    private void viewMovies() {
        System.out.println("\nAvailable Movies and Showtimes:");
        for (int i = 0; i < movies.length; i++) {
            System.out.print((i + 1) + ". ");
            movies[i].displayDetails();
        }
    }

    private void bookTickets() {
        System.out.println("\nSelect a movie by number:");
        for (int i = 0; i < movies.length; i++) {
            System.out.println((i + 1) + ". " + movies[i].getName());
        }
        System.out.print("Your choice: ");
        int movieChoice = getUserInput(1, movies.length);
        if (movieChoice == -1) return;

        Movie selectedMovie = movies[movieChoice - 1];

        System.out.println("Select a showtime by number:");
        Showtime[] showtimes = selectedMovie.getShowtimes();
        for (int i = 0; i < showtimes.length; i++) {
            System.out.println((i + 1) + ". " + showtimes[i]);
        }
        System.out.print("Your choice: ");
        int showtimeChoice = getUserInput(1, showtimes.length);
        if (showtimeChoice == -1) return;

        Showtime selectedShowtime = showtimes[showtimeChoice - 1];

        System.out.print("Enter number of tickets to book: ");
        int tickets = getUserInput(1, selectedShowtime.getAvailableSeats());
        if (tickets == -1) {
            System.out.println("Invalid number of tickets or not enough seats available.");
            return;
        }

        selectedShowtime.bookSeats(tickets);
        System.out.println("\nBooking Confirmed!");
        System.out.println("Movie: " + selectedMovie.getName());
        System.out.println("Showtime: " + selectedShowtime.getTime());
        System.out.println("Tickets Booked: " + tickets);
        System.out.println("Thank you for booking with us!");
    }

    private int getUserInput(int min, int max) {
        String input = scanner.nextLine().trim();
        try {
            int value = Integer.parseInt(input);
            if (value < min || value > max) {
                System.out.println("Please enter a number between " + min + " and " + max + ".");
                return -1;
            }
            return value;
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            return -1;
        }
    }

    public static void main(String[] args) {
        new Booking().start();
    }
}
