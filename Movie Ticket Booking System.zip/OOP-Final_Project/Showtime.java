public class Showtime {
    private String time;
    private int availableSeats;

    public Showtime(String time, int availableSeats) {
        this.time = time;
        this.availableSeats = availableSeats;
    }

    public String getTime() {
        return time;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void bookSeats(int seats) {
        if (seats <= availableSeats) {
            availableSeats -= seats;
        }
    }

    @Override
    public String toString() {
        return time + " - Available Seats: " + availableSeats;
    }
}
