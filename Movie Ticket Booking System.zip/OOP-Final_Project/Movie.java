public class Movie extends Event {
    private Showtime[] showtimes;

    public Movie(String name, Showtime[] showtimes) {
        super(name);
        this.showtimes = showtimes;
    }

    public Showtime[] getShowtimes() {
        return showtimes;
    }

    @Override
    public void displayDetails() {
        System.out.println(getName());
        for (int i = 0; i < showtimes.length; i++) {
            System.out.println("   " + (i + 1) + ") " + showtimes[i]);
        }
    }
}
